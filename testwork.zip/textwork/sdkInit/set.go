package sdkInit

import (
	"fmt"
	"github.com/hyperledger/fabric-sdk-go/pkg/client/channel"
	shell "github.com/ipfs/go-ipfs-api"
	"os"
)

func (t *Application) Set(args []string) (string, error) {
	var tempArgs [][]byte
	for i := 1; i < len(args); i++ {
		tempArgs = append(tempArgs, []byte(args[i]))
	}
	//创建一个交易请求
	request := channel.Request{ChaincodeID: t.SdkEnvInfo.ChaincodeID, Fcn: args[0], Args: [][]byte{[]byte(args[1]), []byte(args[2])}}
	//执行一个交易请求
	response, err := t.SdkEnvInfo.Client.Execute(request)
	if err != nil {
		// 资产转移失败
		return "", err
	}

	//fmt.Println("============== response:",response)
	return string(response.TransactionID), nil
}

//func (t *Application) Setmodel(args []string) (string, string, error) {
//
//	sh := shell.NewShell("localhost:5001") //创建与IPFS节点的连接
//	filePath := args[2]
//	file, err := os.Open(filePath)
//	if err != nil {
//		fmt.Printf("Error opening file: %s\n", err)
//		return "", nil
//	}
//	defer file.Close() // 确保文件在函数结束时关闭
//	// 将文件上传到 IPFS
//	filehash, err := sh.Add(file) //向IPFS添加文件并获取哈希值
//	if err != nil {
//		fmt.Printf("Error adding file to IPFS: %s\n", err)
//		return "", nil
//	}
//
//	fmt.Println("<--- 哈希编号　--->：", filehash)
//
//	request := channel.Request{ChaincodeID: t.SdkEnvInfo.ChaincodeID, Fcn: args[0], Args: [][]byte{[]byte(args[1]), []byte(filehash)}}
//	response, err := t.SdkEnvInfo.Client.Execute(request)
//	if err != nil {
//		// 资产转移失败
//		return "", err
//	}
//	//fmt.Println("============== response:",response)
//	return string(response.TransactionID), nil
//
//}

func (t *Application) Setmodel(args []string) (string, error) {

	sh := shell.NewShell("localhost:5001") //创建与IPFS节点的连接
	filePath := args[2]
	file, err := os.Open(filePath)
	if err != nil {
		fmt.Printf("Error opening file: %s\n", err)
		return "", nil
	}
	defer file.Close() // 确保文件在函数结束时关闭
	// 将文件上传到 IPFS
	filehash, err := sh.Add(file) //向IPFS添加文件并获取哈希值
	if err != nil {
		fmt.Printf("Error adding file to IPFS: %s\n", err)
		return "", nil
	}

	fmt.Println("<--- 哈希编号　--->：", filehash)

	request := channel.Request{ChaincodeID: t.SdkEnvInfo.ChaincodeID, Fcn: args[0], Args: [][]byte{[]byte(args[1]), []byte(filehash)}}
	response, err := t.SdkEnvInfo.Client.Execute(request)
	if err != nil {
		// 资产转移失败
		return "", err
	}
	//fmt.Println("============== response:",response)
	return string(response.TransactionID), nil

}
