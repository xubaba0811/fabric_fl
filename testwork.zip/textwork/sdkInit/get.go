package sdkInit

import (
	"encoding/json"
	"fmt"
	"github.com/hyperledger/fabric-sdk-go/pkg/client/channel"
	shell "github.com/ipfs/go-ipfs-api"
	"io"
	"os"
)

func (t *Application) Get(args []string) (string, error) {
	response, err := t.SdkEnvInfo.Client.Query(channel.Request{ChaincodeID: t.SdkEnvInfo.ChaincodeID, Fcn: args[0], Args: [][]byte{[]byte(args[1])}})
	if err != nil {
		return "", fmt.Errorf("failed to query: %v", err)
	}

	return string(response.Payload), nil
}
func (t *Application) Getmodel(args []string) ([]string, error) {
	response, err := t.SdkEnvInfo.Client.Query(channel.Request{
		ChaincodeID: t.SdkEnvInfo.ChaincodeID,
		Fcn:         args[0],
		Args:        [][]byte{[]byte(args[1])},
	})
	if err != nil {
		return []string{""}, fmt.Errorf("failed to query: %v", err)
	}
	var filelist []string
	// 反序列化json
	//var data []map[string]interface{}
	if err = json.Unmarshal(response.Payload, &filelist); err != nil {
		return []string{""}, fmt.Errorf("failed to 反序列化json: %v", err)
	}

	sh := shell.NewShell("localhost:5001")
	// 循环读取每个文件
	for _, cid := range filelist {
		// 获取文件的读取流
		reader, err := sh.Cat(cid)
		if err != nil {
			fmt.Printf("Error reading file with CID %s from IPFS: %s\n", cid, err)
			continue // 处理下一个文件
		}
		defer reader.Close() // 确保在读取完文件后关闭流
		// 创建一个本地文件以保存内容，文件名基于 CID
		localFileName := fmt.Sprintf("output_%s.pth", cid) // 假设文件是 docx 文件
		localFile, err := os.Create(localFileName)
		if err != nil {
			fmt.Printf("Error creating output file %s: %s\n", localFileName, err)
			continue // 处理下一个文件
		}
		defer localFile.Close() // 确保在函数结束时关闭文件
		// 将从 IPFS 读取的内容写入本地文件
		_, err = io.Copy(localFile, reader)
		if err != nil {
			fmt.Printf("Error saving file %s: %s\n", localFileName, err)
			continue // 处理下一个文件
		}
		fmt.Printf("File with CID %s has been successfully retrieved from IPFS and saved as %s\n", cid, localFileName)
	}
	return filelist, nil
}
