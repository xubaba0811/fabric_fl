package main

import (
	"bytes"
	"fmt"
	"log"
	"os"
	"os/exec"
	"testwork/sdkInit"
	"time"
)

const (
	cc_name    = "smallbank"
	cc_version = "1.0"
)

var App sdkInit.Application //app

func main() {
	// 创建一个命令来运行 Python 脚本
	cmd := exec.Command("python3", "aggregate.py")

	// 捕获脚本的输出
	var out bytes.Buffer
	cmd.Stdout = &out

	// 运行命令
	err := cmd.Run()
	if err != nil {
		log.Fatalf("Failed to run Python script: %v", err)
	}

	// 打印输出结果
	fmt.Printf("Python script output: %s\n", out.String())

	//org信息
	orgs := []*sdkInit.OrgInfo{
		{
			OrgAdminUser:  "Admin",
			OrgName:       "Org1",
			OrgMspId:      "Org1MSP",
			OrgUser:       "User1",
			OrgPeerNum:    1,
			OrgAnchorFile: "/home/shuai/go/src/testwork/fixtures/channel-artifacts/Org1MSPanchors.tx",
		},
		{
			OrgAdminUser:  "Admin",
			OrgName:       "Org2",
			OrgMspId:      "Org2MSP",
			OrgUser:       "User1",
			OrgPeerNum:    1,
			OrgAnchorFile: "/home/shuai/go/src/testwork/fixtures/channel-artifacts/Org2MSPanchors.tx",
		},
		{
			OrgAdminUser:  "Admin",
			OrgName:       "Org3",
			OrgMspId:      "Org3MSP",
			OrgUser:       "User1",
			OrgPeerNum:    1,
			OrgAnchorFile: "/home/shuai/go/src/testwork/fixtures/channel-artifacts/Org3MSPanchors.tx",
		},
		{
			OrgAdminUser:  "Admin",
			OrgName:       "Org4",
			OrgMspId:      "Org4MSP",
			OrgUser:       "User1",
			OrgPeerNum:    1,
			OrgAnchorFile: "/home/shuai/go/src/testwork/fixtures/channel-artifacts/Org4MSPanchors.tx",
		},
	}
	// 初始化info
	info := sdkInit.SdkEnvInfo{
		ChannelID:        "mychannel",
		ChannelConfig:    "/home/shuai/go/src/testwork/fixtures/channel-artifacts/channel.tx",
		Orgs:             orgs,
		OrdererAdminUser: "Admin",
		OrdererOrgName:   "OrdererOrg",
		OrdererEndpoint:  "orderer1.example.com",
		ChaincodeID:      cc_name,
		ChaincodePath:    "/home/shuai/go/src/testwork/chaincode/go/smallbank",
		ChaincodeVersion: cc_version,
	}
	sdk, err := sdkInit.Setup("config.yaml", &info)
	if err != nil {
		fmt.Println(">> Sdk set error ", err)
		os.Exit(-1)
	}
	if err := sdkInit.CreateChannel(&info); err != nil {
		fmt.Println(">> Create channel error: ", err)
		os.Exit(-1)
	}
	if err := sdkInit.JoinChannel(&info); err != nil {
		fmt.Println(">> join channel error: ", err)
		os.Exit(-1)
	}
	//chaincode operation
	packageID, err := sdkInit.InstallCC(&info)
	if err != nil {
		fmt.Println(">> install chaincode error: ", err)
		os.Exit(-1)
	}
	//apprrove
	if err := sdkInit.ApproveLifecycle(&info, 1, packageID); err != nil {
		fmt.Println(">> approve chaincode error: ", err)
		os.Exit(-1)
	}
	//init chaincode
	if err := sdkInit.InitCC(&info, false, sdk); err != nil {
		fmt.Println(">> init chaincode error: ", err)
		os.Exit(-1)
	}
	fmt.Println(">> Set the chain code status through the chain code external service......")
	if err := info.InitService(info.ChaincodeID, info.ChannelID, info.Orgs[0], sdk); err != nil {
		fmt.Println(">> InitService error: ", err)
		os.Exit(-1)
	}
	App = sdkInit.Application{
		SdkEnvInfo: &info,
	}
	fmt.Println(">> Set chain code status completed")

	////脚本运行python
	//cmd := exec.Command("python3", "../fl/aggregate.py")
	//var out bytes.Buffer
	//cmd.Stdout = &out
	//err_py := cmd.Run()
	//if err_py != nil {
	//	log.Fatalf("Failed to run Python script: %v", err_py)
	//}

	//go
	test := []string{"setmodel", "local", "/home/shuai/go/src/testwork/models/global_model.pth"}
	ret, err := App.Setmodel(test)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("<--- 上传本地模型　--->：", ret)

	test = []string{"setmodel", "local", "/home/shuai/go/src/testwork/models/initial_model.pth"}
	ret, err = App.Setmodel(test)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("<--- 上传本地模型　--->：", ret)

	test = []string{"setmodel", "local", "/home/shuai/go/src/testwork/models/org1_model.pth"}
	ret, err = App.Setmodel(test)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("<--- 上传本地模型　--->：", ret)

	test = []string{"setmodel", "local", "/home/shuai/go/src/testwork/models/org2_model.pth"}
	ret, err = App.Setmodel(test)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("<--- 上传本地模型　--->：", ret)

	test = []string{"setmodel", "local", "/home/shuai/go/src/testwork/models/org3_model.pth"}
	ret, err = App.Setmodel(test)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("<--- 上传本地模型　--->：", ret)

	test = []string{"setmodel", "local", "/home/shuai/go/src/testwork/models/org4_model.pth"}
	ret, err = App.Setmodel(test)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("<--- 上传本地模型　--->：", ret)

	test = []string{"setmodel", "local", "/home/shuai/go/src/testwork/models/org5_model.pth"}
	ret, err = App.Setmodel(test)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("<--- 上传本地模型　--->：", ret)

	test = []string{"getmodel", "local"}
	//var response []string
	var filelist []string
	filelist, err = App.Getmodel(test) //查询链码状态
	//fmt.Println(len(filelist))
	fmt.Println("<--- testtesttest　--->：filehash:", filelist[0])
	//fmt.Println("<--- testtesttest　--->：filehash:", filelist[1])
	if err != nil {
		fmt.Println(err)
	}
	time.Sleep(time.Second * 10)
}
