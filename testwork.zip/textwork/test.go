package main

import (
    "bytes"
    "fmt"
    "log"
    "os/exec"
)

func main() {
    // 创建一个命令来运行 Python 脚本
    cmd := exec.Command("python3", "aggregate.py")

    // 捕获脚本的输出
    var out bytes.Buffer
    cmd.Stdout = &out

    // 运行命令
    err := cmd.Run()
    if err != nil {
        log.Fatalf("Failed to run Python script: %v", err)
    }

    // 打印输出结果
    fmt.Printf("Python script output: %s\n", out.String())
}
