package main

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

// SimpleAsset implements a simple chaincode to manage an asset
type SimpleAsset struct {
}
type outputEvent struct {
	EventName string
}

// Init is called during chaincode instantiation to initialize any
// data. Note that chaincode upgrade also calls this function to reset
// or to migrate data.
func (t *SimpleAsset) Init(stub shim.ChaincodeStubInterface) peer.Response {
	fmt.Printf("init...")
	return shim.Success(nil)
}

// Invoke is called per transaction on the chaincode. Each transaction is
// either a 'get' or a 'set' on the asset created by Init function. The Set
// method may create a new asset by specifying a new key-value pair.
func (t *SimpleAsset) Invoke(stub shim.ChaincodeStubInterface) peer.Response {
	// Extract the function and args from the transaction proposal
	fn, args := stub.GetFunctionAndParameters()

	var result string
	var err error
	if fn == "set" {
		result, err = set(stub, args)
	}
	if fn == "get" { // assume 'get' even if fn is nil
		result, err = get(stub, args)
	}
	if fn == "setmodel" {
		result, err = setmodel(stub, args)
	}
	if fn == "getmodel" {
		result, err = getmodel(stub, args)
	}
	if err != nil {
		return shim.Error(err.Error())
	}

	// Return the result as success payload
	return shim.Success([]byte(result))
}

// Set stores the asset (both key and value) on the ledger. If the key exists,
// it will override the value with the new one
func set(stub shim.ChaincodeStubInterface, args []string) (string, error) {
	if len(args) != 2 {
		return "", fmt.Errorf("Incorrect arguments. Expecting a key and a value")
	}

	err := stub.PutState(args[0], []byte(args[1]))
	if err != nil {
		return "", fmt.Errorf("Failed to set asset: %s", args[0])
	}
	event := outputEvent{
		EventName: "set",
	}
	payload, err := json.Marshal(event)
	if err != nil {
		return "", err
	}
	err = stub.SetEvent("chaincode-event", payload)
	return args[1], nil
}

// Get returns the value of the specified asset key
func get(stub shim.ChaincodeStubInterface, args []string) (string, error) {
	if len(args) != 1 {
		return "", fmt.Errorf("Incorrect arguments. Expecting a key")
	}

	value, err := stub.GetState(args[0])
	if err != nil {
		return "", fmt.Errorf("Failed to get asset: %s with error: %s", args[0], err)
	}
	if value == nil {
		return "", fmt.Errorf("Asset not found: %s", args[0])
	}
	return string(value), nil
}

//func setmodel(stub shim.ChaincodeStubInterface, args []string) (string, string, error) {
//	startTime := time.Now() // 获取开始时间
//
//	if len(args) != 2 {
//		return "", fmt.Errorf("Incorrect arguments. Expecting a key and a value")
//	}
//	modelkey := args[0]
//	filehash := args[1]
//	var key string
//	fileID := stub.GetTxID()[:16]
//	if val, err := stub.CreateCompositeKey(modelkey, []string{fileID}); err != nil {
//		return "", fmt.Errorf("创建复合主键出错")
//	} else {
//		key = val
//	}
//	err := stub.PutState(key, []byte(filehash))
//	if err != nil {
//		return "", fmt.Errorf("Failed to set asset: %s", args[0])
//	}
//
//	// 计算所需时间
//	duration := time.Since(startTime) // 计算经过的时间
//	fmt.Printf("setmodel执行时间: %v\n", duration)
//
//	fmt.Println("<--- testtesttest　--->：filehash:", filehash)
//	fmt.Println("<--- testtesttest　--->：fileID:", fileID)
//	event := outputEvent{
//		EventName: "setmodel",
//	}
//	payload, err := json.Marshal(event)
//	if err != nil {
//		return "", err
//	}
//	err = stub.SetEvent("chaincode-event", payload)
//	return args[1], string(duration), nil
//	//return string(duration), nil
//}

func setmodel(stub shim.ChaincodeStubInterface, args []string) (string, error) {
	startTime := time.Now() // 获取开始时间

	if len(args) != 2 {
		return "", fmt.Errorf("Incorrect arguments. Expecting a key and a value")
	}
	modelkey := args[0]
	filehash := args[1]
	var key string
	fileID := stub.GetTxID()[:16]
	if val, err := stub.CreateCompositeKey(modelkey, []string{fileID}); err != nil {
		return "", fmt.Errorf("创建复合主键出错")
	} else {
		key = val
	}
	err := stub.PutState(key, []byte(filehash))
	if err != nil {
		return "", fmt.Errorf("Failed to set asset: %s", args[0])
	}

	// 计算所需时间
	duration := time.Since(startTime) // 计算经过的时间
	fmt.Printf("setmodel执行时间: %v\n", duration)

	fmt.Println("<--- testtesttest　--->：filehash:", filehash)
	fmt.Println("<--- testtesttest　--->：fileID:", fileID)
	event := outputEvent{
		EventName: "setmodel",
	}
	payload, err := json.Marshal(event)
	if err != nil {
		return "", err
	}
	err = stub.SetEvent("chaincode-event", payload)
	return args[1], nil
	//return string(duration), nil
}
func getmodel(stub shim.ChaincodeStubInterface, args []string) (string, error) {
	if len(args) != 1 {
		return "", fmt.Errorf("Incorrect arguments. Expecting a key")
	}
	modelkey := args[0]
	//resultIterator, err := stub.GetStateByPartialCompositeKey(modelkey, []string{""})
	resultIterator, err := stub.GetStateByPartialCompositeKey(modelkey, nil)
	if err != nil {
		return "", fmt.Errorf("%s-获取全部数据出错: %s", modelkey, err)
	}
	defer resultIterator.Close()
	//检查返回的数据是否为空，不为空则遍历数据，否则返回空数组
	var results [][]byte
	for resultIterator.HasNext() {
		val, err := resultIterator.Next()
		if err != nil {
			return "", fmt.Errorf("%s-返回的数据出错: %s", modelkey, err)
		}
		results = append(results, val.GetValue())
	}

	var filelist []string
	for _, v := range results {
		if v != nil {
			filelist = append(filelist, string(v))
		}
	}
	filelistByte, err := json.Marshal(filelist)
	if err != nil {
		return "", fmt.Errorf("filelist-序列化出错: %s", err)
	}
	return string(filelistByte), nil

}

// main function starts up the chaincode in the container during instantiate
func main() {
	if err := shim.Start(new(SimpleAsset)); err != nil {
		fmt.Printf("Error starting SimpleAsset chaincode: %s", err)
	}
}
