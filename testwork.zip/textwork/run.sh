#!/bin/bash

# 脚本运行aggregate.py文件
python3 aggregate.py
if [ $? -ne 0 ]; then
    echo "Error running aggregate.py"
    exit 1
fi

# 脚本运行main.go文件
go run main.go
if [ $? -ne 0 ]; then
    echo "Error running main.go"
    exit 1
fi

echo "Both scripts have been executed successfully."
